// Put all the javascript code here, that you want to execute after page load.
// access database and warn users if this website tends to be biased
// get message from background_script.js and manipulate the current website (highlight paragraphs) and show message/data on pop up.
console.log("Content script ran.");
