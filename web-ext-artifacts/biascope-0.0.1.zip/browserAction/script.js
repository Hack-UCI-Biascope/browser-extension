// document.getElementById('myHeading').style.color = 'red'
console.log("popup script working");
